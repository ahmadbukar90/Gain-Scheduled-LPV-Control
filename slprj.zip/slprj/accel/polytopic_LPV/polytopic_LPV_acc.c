#include "__cf_polytopic_LPV.h"
#include <math.h>
#include "polytopic_LPV_acc.h"
#include "polytopic_LPV_acc_private.h"
#include <stdio.h>
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
static void mdlOutputs ( SimStruct * S , int_T tid ) { real_T ofz003z5gh ;
int_T ci ; real_T currentTime ; real_T evfs2ol0gi ; real_T nqdzb0a4hj ;
real_T mbgnontotz ; real_T cn4cvwrv54 ; real_T dwzrqj51mx ; real_T ob0ogcwwgs
; real_T pujmpl02np ; static const int8_T jc [ 21 ] = { 0 , 1 , 2 , 3 , 4 , 5
, 6 , 0 , 1 , 2 , 3 , 4 , 5 , 6 , 0 , 1 , 2 , 3 , 4 , 5 , 6 } ; n3qi1whofz *
_rtB ; loikxjbxjg * _rtP ; f1xhd02yjc * _rtX ; ew10rzwqr2 * _rtDW ; _rtDW = (
( ew10rzwqr2 * ) ssGetRootDWork ( S ) ) ; _rtX = ( ( f1xhd02yjc * )
ssGetContStates ( S ) ) ; _rtP = ( ( loikxjbxjg * ) ssGetDefaultParam ( S ) )
; _rtB = ( ( n3qi1whofz * ) _ssGetBlockIO ( S ) ) ; _rtB -> lcpejibsoq = ( (
f1xhd02yjc * ) ssGetContStates ( S ) ) -> ger5geuygj ; ssCallAccelRunBlock (
S , 0 , 1 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> ifj2n0fmod = 0.0 ; _rtB ->
ifj2n0fmod += _rtP -> P_3 * _rtX -> d0zovkvyyy [ 1 ] ; ssCallAccelRunBlock (
S , 0 , 3 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> ogps3thijs [ 0 ] = 0.0 ; _rtB ->
ogps3thijs [ 1 ] = 0.0 ; _rtB -> ogps3thijs [ 2 ] = 0.0 ; for ( ci = 0 ; ci <
7 ; ci ++ ) { _rtB -> ogps3thijs [ 0 ] += _rtP -> P_6 [ ci ] * _rtX ->
afhnh413zc [ jc [ ci ] ] ; } while ( ci < 14 ) { _rtB -> ogps3thijs [ 1 ] +=
_rtP -> P_6 [ ci ] * _rtX -> afhnh413zc [ jc [ ci ] ] ; ci ++ ; } while ( ci
< 21 ) { _rtB -> ogps3thijs [ 2 ] += _rtP -> P_6 [ ci ] * _rtX -> afhnh413zc
[ jc [ ci ] ] ; ci ++ ; } ssCallAccelRunBlock ( S , 0 , 5 ,
SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtB ->
onrucqj1mj = _rtP -> P_7 ; _rtB -> dhq1qqckyv = _rtP -> P_8 ; }
ssCallAccelRunBlock ( S , 0 , 8 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> bitvrsufqf
= ( ( f1xhd02yjc * ) ssGetContStates ( S ) ) -> btccuwk0b2 ;
ssCallAccelRunBlock ( S , 0 , 10 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> af5tlzf2mp
= muDoubleScalarSin ( _rtP -> P_12 * ssGetTaskTime ( S , 0 ) + _rtP -> P_13 )
* _rtP -> P_10 + _rtP -> P_11 ; _rtB -> p4r2wh2dgn = _rtB -> ifj2n0fmod -
_rtB -> lcpejibsoq ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { currentTime =
ssGetTaskTime ( S , 1 ) ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW ->
e5acncgfzu = ( currentTime >= _rtP -> P_14 ) ; } if ( _rtDW -> e5acncgfzu ==
1 ) { _rtB -> bxps5rkb00 = _rtP -> P_16 ; } else { _rtB -> bxps5rkb00 = _rtP
-> P_15 ; } } ofz003z5gh = ssGetT ( S ) ; if ( ssIsSampleHit ( S , 1 , 0 ) )
{ _rtB -> oxlnykljmd = _rtP -> P_17 ; } evfs2ol0gi = ( ofz003z5gh - _rtB ->
oxlnykljmd ) * _rtB -> bxps5rkb00 ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtB
-> aznpaj1npj = _rtP -> P_18 ; } if ( ssIsSampleHit ( S , 1 , 0 ) ) {
currentTime = ssGetTaskTime ( S , 1 ) ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> ooleie2o4t = ( currentTime >= _rtP -> P_19 ) ; } if ( _rtDW ->
ooleie2o4t == 1 ) { _rtB -> oa53opyp02 = _rtP -> P_21 ; } else { _rtB ->
oa53opyp02 = _rtP -> P_20 ; } } ofz003z5gh = ssGetT ( S ) ; if (
ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> d4rdz1kkfo = _rtP -> P_22 ; }
nqdzb0a4hj = ( ofz003z5gh - _rtB -> d4rdz1kkfo ) * _rtB -> oa53opyp02 ; if (
ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> olrxx3rbta = _rtP -> P_23 ; } if (
ssIsSampleHit ( S , 1 , 0 ) ) { currentTime = ssGetTaskTime ( S , 1 ) ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> a301jyjgqb = ( currentTime >= _rtP ->
P_24 ) ; } if ( _rtDW -> a301jyjgqb == 1 ) { _rtB -> erseopxbjk = _rtP ->
P_26 ; } else { _rtB -> erseopxbjk = _rtP -> P_25 ; } } ofz003z5gh = ssGetT (
S ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> awam40rxyc = _rtP -> P_27
; } mbgnontotz = ( ofz003z5gh - _rtB -> awam40rxyc ) * _rtB -> erseopxbjk ;
if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> mjiin43sac = _rtP -> P_28 ; } if
( ssIsSampleHit ( S , 1 , 0 ) ) { currentTime = ssGetTaskTime ( S , 1 ) ; if
( ssIsMajorTimeStep ( S ) ) { _rtDW -> fzgprwuxtz = ( currentTime >= _rtP ->
P_29 ) ; } if ( _rtDW -> fzgprwuxtz == 1 ) { _rtB -> ptsxisqi0v = _rtP ->
P_31 ; } else { _rtB -> ptsxisqi0v = _rtP -> P_30 ; } } ofz003z5gh = ssGetT (
S ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> ama03jjatq = _rtP -> P_32
; } cn4cvwrv54 = ( ofz003z5gh - _rtB -> ama03jjatq ) * _rtB -> ptsxisqi0v ;
if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> o3kl44l3rw = _rtP -> P_33 ; } if
( ssIsSampleHit ( S , 1 , 0 ) ) { currentTime = ssGetTaskTime ( S , 1 ) ; if
( ssIsMajorTimeStep ( S ) ) { _rtDW -> cfb1ni5k1b = ( currentTime >= _rtP ->
P_34 ) ; } if ( _rtDW -> cfb1ni5k1b == 1 ) { _rtB -> koi1q2iwgf = _rtP ->
P_36 ; } else { _rtB -> koi1q2iwgf = _rtP -> P_35 ; } } ofz003z5gh = ssGetT (
S ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> lnduc4osrx = _rtP -> P_37
; _rtB -> ez2ic5kl35 = _rtP -> P_38 ; } dwzrqj51mx = ( ofz003z5gh - _rtB ->
lnduc4osrx ) * _rtB -> koi1q2iwgf + _rtB -> ez2ic5kl35 ; if ( ssIsSampleHit (
S , 1 , 0 ) ) { currentTime = ssGetTaskTime ( S , 1 ) ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> mm1xazuic4 = ( currentTime >= _rtP ->
P_39 ) ; } if ( _rtDW -> mm1xazuic4 == 1 ) { _rtB -> jq100qg3yo = _rtP ->
P_41 ; } else { _rtB -> jq100qg3yo = _rtP -> P_40 ; } } ofz003z5gh = ssGetT (
S ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> bwnvw20fvc = _rtP -> P_42
; _rtB -> by2pis3u5d = _rtP -> P_43 ; } ob0ogcwwgs = ( ofz003z5gh - _rtB ->
bwnvw20fvc ) * _rtB -> jq100qg3yo + _rtB -> by2pis3u5d ; if ( ssIsSampleHit (
S , 1 , 0 ) ) { currentTime = ssGetTaskTime ( S , 1 ) ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> hcal4pvuye = ( currentTime >= _rtP ->
P_44 ) ; } if ( _rtDW -> hcal4pvuye == 1 ) { _rtB -> jz0yimgtok = _rtP ->
P_46 ; } else { _rtB -> jz0yimgtok = _rtP -> P_45 ; } } ofz003z5gh = ssGetT (
S ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> pphip2fzxk = _rtP -> P_47
; _rtB -> jwsgyqkgv0 = _rtP -> P_48 ; } pujmpl02np = ( ofz003z5gh - _rtB ->
pphip2fzxk ) * _rtB -> jz0yimgtok + _rtB -> jwsgyqkgv0 ; if ( ssIsSampleHit (
S , 1 , 0 ) ) { currentTime = ssGetTaskTime ( S , 1 ) ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> gada1zyxdv = ( currentTime >= _rtP ->
P_49 ) ; } if ( _rtDW -> gada1zyxdv == 1 ) { _rtB -> hbyqtzzb4o = _rtP ->
P_51 ; } else { _rtB -> hbyqtzzb4o = _rtP -> P_50 ; } } ofz003z5gh = ssGetT (
S ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> b20xoyxmhr = _rtP -> P_52
; _rtB -> mn0sbkufgt = _rtP -> P_53 ; } _rtB -> bitvrsufqf = ( ( ( ( (
evfs2ol0gi + _rtB -> aznpaj1npj ) + ( nqdzb0a4hj + _rtB -> olrxx3rbta ) ) + (
mbgnontotz + _rtB -> mjiin43sac ) ) + ( cn4cvwrv54 + _rtB -> o3kl44l3rw ) ) -
( ( ( ofz003z5gh - _rtB -> b20xoyxmhr ) * _rtB -> hbyqtzzb4o + _rtB ->
mn0sbkufgt ) + ( ( dwzrqj51mx + ob0ogcwwgs ) + pujmpl02np ) ) * _rtP -> P_54
) * _rtP -> P_55 ; ssCallAccelRunBlock ( S , 0 , 74 , SS_CALL_MDL_OUTPUTS ) ;
UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { n3qi1whofz * _rtB ;
loikxjbxjg * _rtP ; _rtP = ( ( loikxjbxjg * ) ssGetDefaultParam ( S ) ) ;
_rtB = ( ( n3qi1whofz * ) _ssGetBlockIO ( S ) ) ; UNUSED_PARAMETER ( tid ) ;
}
#define MDL_DERIVATIVES
static void mdlDerivatives ( SimStruct * S ) { int_T is ; int_T ci ; static
const int8_T ir [ 8 ] = { 0 , 7 , 14 , 16 , 23 , 24 , 31 , 38 } ; static
const int8_T ir_p [ 8 ] = { 0 , 0 , 0 , 1 , 1 , 1 , 1 , 1 } ; static const
int8_T jc [ 38 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 0 , 1 , 2 , 3 , 4 , 5 , 6 ,
1 , 2 , 0 , 1 , 2 , 3 , 4 , 5 , 6 , 3 , 0 , 1 , 2 , 3 , 4 , 5 , 6 , 0 , 1 , 2
, 3 , 4 , 5 , 6 } ; n3qi1whofz * _rtB ; loikxjbxjg * _rtP ; f1xhd02yjc * _rtX
; pqmvzr1kvu * _rtXdot ; _rtXdot = ( ( pqmvzr1kvu * ) ssGetdX ( S ) ) ; _rtX
= ( ( f1xhd02yjc * ) ssGetContStates ( S ) ) ; _rtP = ( ( loikxjbxjg * )
ssGetDefaultParam ( S ) ) ; _rtB = ( ( n3qi1whofz * ) _ssGetBlockIO ( S ) ) ;
{ ( ( pqmvzr1kvu * ) ssGetdX ( S ) ) -> ger5geuygj = _rtB -> jkwnvujutt [ 1 ]
; } _rtXdot -> d0zovkvyyy [ 0 ] = 0.0 ; _rtXdot -> d0zovkvyyy [ 1 ] = 0.0 ;
_rtXdot -> d0zovkvyyy [ 0U ] += _rtP -> P_1 [ 0 ] * _rtX -> d0zovkvyyy [ 0 ]
; _rtXdot -> d0zovkvyyy [ 0U ] += _rtP -> P_1 [ 1 ] * _rtX -> d0zovkvyyy [ 1
] ; _rtXdot -> d0zovkvyyy [ 1U ] += _rtP -> P_1 [ 2 ] * _rtX -> d0zovkvyyy [
0 ] ; _rtXdot -> d0zovkvyyy [ 1U ] += _rtP -> P_1 [ 3 ] * _rtX -> d0zovkvyyy
[ 1 ] ; _rtXdot -> d0zovkvyyy [ 0U ] += _rtP -> P_2 [ 0 ] * _rtB ->
af5tlzf2mp ; _rtXdot -> d0zovkvyyy [ 1U ] += _rtP -> P_2 [ 1 ] * _rtB ->
af5tlzf2mp ; for ( is = 0 ; is < 7 ; is ++ ) { _rtXdot -> afhnh413zc [ is ] =
0.0 ; } for ( is = 0 ; is < 7 ; is ++ ) { for ( ci = ir [ is ] ; ci < ir [ is
+ 1 ] ; ci ++ ) { _rtXdot -> afhnh413zc [ is ] += _rtP -> P_4 [ ci ] * _rtX
-> afhnh413zc [ jc [ ci ] ] ; } } for ( is = 0 ; is < 7 ; is ++ ) { ci = ir_p
[ is ] ; while ( ci < ir_p [ is + 1 ] ) { _rtXdot -> afhnh413zc [ is ] +=
_rtP -> P_5 * _rtB -> p4r2wh2dgn ; ci = 1 ; } } { ( ( pqmvzr1kvu * ) ssGetdX
( S ) ) -> btccuwk0b2 = _rtB -> jkwnvujutt [ 0 ] ; } }
#define MDL_ZERO_CROSSINGS
static void mdlZeroCrossings ( SimStruct * S ) { loikxjbxjg * _rtP ;
d15n1ti4kq * _rtZCSV ; _rtZCSV = ( ( d15n1ti4kq * ) ssGetSolverZcSignalVector
( S ) ) ; _rtP = ( ( loikxjbxjg * ) ssGetDefaultParam ( S ) ) ; _rtZCSV ->
pvlc4ithih = ssGetT ( S ) - _rtP -> P_14 ; _rtZCSV -> ebkgmnizrt = ssGetT ( S
) - _rtP -> P_19 ; _rtZCSV -> gmbjnrogwr = ssGetT ( S ) - _rtP -> P_24 ;
_rtZCSV -> fkaohgf5l0 = ssGetT ( S ) - _rtP -> P_29 ; _rtZCSV -> g51it45wox =
ssGetT ( S ) - _rtP -> P_34 ; _rtZCSV -> os5alvby5f = ssGetT ( S ) - _rtP ->
P_39 ; _rtZCSV -> iao5jbrjwa = ssGetT ( S ) - _rtP -> P_44 ; _rtZCSV ->
g5jasmpwxi = ssGetT ( S ) - _rtP -> P_49 ; } static void mdlInitializeSizes (
SimStruct * S ) { ssSetChecksumVal ( S , 0 , 392762660U ) ; ssSetChecksumVal
( S , 1 , 757698895U ) ; ssSetChecksumVal ( S , 2 , 2601900169U ) ;
ssSetChecksumVal ( S , 3 , 452392690U ) ; { mxArray * slVerStructMat = NULL ;
mxArray * slStrMat = mxCreateString ( "simulink" ) ; char slVerChar [ 10 ] ;
int status = mexCallMATLAB ( 1 , & slVerStructMat , 1 , & slStrMat , "ver" )
; if ( status == 0 ) { mxArray * slVerMat = mxGetField ( slVerStructMat , 0 ,
"Version" ) ; if ( slVerMat == NULL ) { status = 1 ; } else { status =
mxGetString ( slVerMat , slVerChar , 10 ) ; } } mxDestroyArray ( slStrMat ) ;
mxDestroyArray ( slVerStructMat ) ; if ( ( status == 1 ) || ( strcmp (
slVerChar , "8.3" ) != 0 ) ) { return ; } } ssSetOptions ( S ,
SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork ( S ) != sizeof (
ew10rzwqr2 ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( n3qi1whofz ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
loikxjbxjg ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetDefaultParam ( S , (
real_T * ) & o2iu0a2jke ) ; } static void mdlInitializeSampleTimes (
SimStruct * S ) { } static void mdlTerminate ( SimStruct * S ) { }
#include "simulink.c"
