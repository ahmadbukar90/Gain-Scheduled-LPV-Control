#include "__cf_polytopic_LPV.h"
#ifndef RTW_HEADER_polytopic_LPV_acc_types_h_
#define RTW_HEADER_polytopic_LPV_acc_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
typedef struct loikxjbxjg_ loikxjbxjg ;
#endif
