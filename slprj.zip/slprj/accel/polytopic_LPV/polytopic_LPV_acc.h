#include "__cf_polytopic_LPV.h"
#ifndef RTW_HEADER_polytopic_LPV_acc_h_
#define RTW_HEADER_polytopic_LPV_acc_h_
#include <stddef.h>
#ifndef polytopic_LPV_acc_COMMON_INCLUDES_
#define polytopic_LPV_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn 
#define S_FUNCTION_LEVEL 2
#define RTW_GENERATED_S_FUNCTION
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "polytopic_LPV_acc_types.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "rt_defines.h"
typedef struct { real_T onrucqj1mj ; real_T dhq1qqckyv ; real_T jkwnvujutt [
2 ] ; real_T af5tlzf2mp ; real_T p4r2wh2dgn ; real_T bxps5rkb00 ; real_T
oxlnykljmd ; real_T aznpaj1npj ; real_T oa53opyp02 ; real_T d4rdz1kkfo ;
real_T olrxx3rbta ; real_T erseopxbjk ; real_T awam40rxyc ; real_T mjiin43sac
; real_T ptsxisqi0v ; real_T ama03jjatq ; real_T o3kl44l3rw ; real_T
koi1q2iwgf ; real_T lnduc4osrx ; real_T ez2ic5kl35 ; real_T jq100qg3yo ;
real_T bwnvw20fvc ; real_T by2pis3u5d ; real_T jz0yimgtok ; real_T pphip2fzxk
; real_T jwsgyqkgv0 ; real_T hbyqtzzb4o ; real_T b20xoyxmhr ; real_T
mn0sbkufgt ; real_T lcpejibsoq ; real_T ifj2n0fmod ; real_T ogps3thijs [ 3 ]
; real_T bitvrsufqf ; } n3qi1whofz ; typedef struct { struct { void *
LoggedData ; } ol2dbzzaxz ; struct { void * LoggedData ; } pllcdgse1k ;
struct { void * LoggedData ; } l5yba2gucz ; struct { void * LoggedData ; }
dy3gjx1xi4 ; struct { void * LoggedData ; } p3djgedd4s ; int_T e5acncgfzu ;
int_T ooleie2o4t ; int_T a301jyjgqb ; int_T fzgprwuxtz ; int_T cfb1ni5k1b ;
int_T mm1xazuic4 ; int_T hcal4pvuye ; int_T gada1zyxdv ; } ew10rzwqr2 ;
typedef struct { real_T ger5geuygj ; real_T d0zovkvyyy [ 2 ] ; real_T
afhnh413zc [ 7 ] ; real_T btccuwk0b2 ; } f1xhd02yjc ; typedef struct { real_T
ger5geuygj ; real_T d0zovkvyyy [ 2 ] ; real_T afhnh413zc [ 7 ] ; real_T
btccuwk0b2 ; } pqmvzr1kvu ; typedef struct { boolean_T ger5geuygj ; boolean_T
d0zovkvyyy [ 2 ] ; boolean_T afhnh413zc [ 7 ] ; boolean_T btccuwk0b2 ; }
biadadh31q ; typedef struct { real_T ger5geuygj ; real_T d0zovkvyyy [ 2 ] ;
real_T afhnh413zc [ 7 ] ; real_T btccuwk0b2 ; } dnp02qqx2g ; typedef struct {
real_T pvlc4ithih ; real_T ebkgmnizrt ; real_T gmbjnrogwr ; real_T fkaohgf5l0
; real_T g51it45wox ; real_T os5alvby5f ; real_T iao5jbrjwa ; real_T
g5jasmpwxi ; } d15n1ti4kq ; typedef struct { ZCSigState ooravjtpcu ;
ZCSigState duhuwcioho ; ZCSigState imeksdmnke ; ZCSigState b1cq4r5ryp ;
ZCSigState irm15l2jz5 ; ZCSigState jg0q0m3f50 ; ZCSigState ack13bx2ul ;
ZCSigState jdcxmz1pd2 ; } o24blyp2sp ; struct loikxjbxjg_ { real_T P_0 ;
real_T P_1 [ 4 ] ; real_T P_2 [ 2 ] ; real_T P_3 ; real_T P_4 [ 38 ] ; real_T
P_5 ; real_T P_6 [ 21 ] ; real_T P_7 ; real_T P_8 ; real_T P_9 ; real_T P_10
; real_T P_11 ; real_T P_12 ; real_T P_13 ; real_T P_14 ; real_T P_15 ;
real_T P_16 ; real_T P_17 ; real_T P_18 ; real_T P_19 ; real_T P_20 ; real_T
P_21 ; real_T P_22 ; real_T P_23 ; real_T P_24 ; real_T P_25 ; real_T P_26 ;
real_T P_27 ; real_T P_28 ; real_T P_29 ; real_T P_30 ; real_T P_31 ; real_T
P_32 ; real_T P_33 ; real_T P_34 ; real_T P_35 ; real_T P_36 ; real_T P_37 ;
real_T P_38 ; real_T P_39 ; real_T P_40 ; real_T P_41 ; real_T P_42 ; real_T
P_43 ; real_T P_44 ; real_T P_45 ; real_T P_46 ; real_T P_47 ; real_T P_48 ;
real_T P_49 ; real_T P_50 ; real_T P_51 ; real_T P_52 ; real_T P_53 ; real_T
P_54 ; real_T P_55 ; } ; extern loikxjbxjg o2iu0a2jke ;
#endif
