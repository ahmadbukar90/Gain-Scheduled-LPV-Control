function F = plus(x,y)

F = lmi(x) + lmi(y);