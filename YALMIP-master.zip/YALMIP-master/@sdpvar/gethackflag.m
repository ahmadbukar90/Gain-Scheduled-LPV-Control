function y = gethackflag(X)
%GETHACKFLAG Internal function to extract constraint type

y = X.typeflag;
