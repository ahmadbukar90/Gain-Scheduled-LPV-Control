function X = dissect(Y)

X = dissect_internal(Y);